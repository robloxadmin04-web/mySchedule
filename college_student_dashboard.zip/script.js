const KEY="collegeDashboard_v1";
const DAYS=["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"];
const DEFAULTS={
 profile:{name:"Student",studentId:"",program:"My Program",year:"",section:"",school:"My College",email:"",greeting:"A focused day starts with a clear plan."},
 settings:{theme:"system",weekStart:"monday",timeFormat:"24",classDuration:60,defaultClassType:"Face to Face",defaultPriority:"Medium",defaultTaskStatus:"Not Started",sortOrder:"due",passing:60,target:90,precision:1,gradingSystem:"Weighted percentage",focus:25,short:5,long:15,sessionsLong:4,layout:"comfortable",radius:"soft",reduceMotion:false},
 classTypes:["Zoom","Face to Face","Online","Other"],
 classes:[],assignments:[],subjects:[],notes:[],files:[],
 grades:[{id:id(),name:"Quiz",score:"",max:"100",weight:"20"},{id:id(),name:"Assignment",score:"",max:"100",weight:"30"},{id:id(),name:"Exam",score:"",max:"100",weight:"50"}],
 focus:{sessions:0,minutes:0,history:[]},
 widgets:{nextClass:true,todaySchedule:true,todayTasks:true,deadlines:true,weeklyProgress:true,focusStats:true,quickActions:true}
};
let state=load();
let timer={mode:"focus",remaining:state.settings.focus*60,total:state.settings.focus*60,running:false,interval:null};
let archivedVisible=false;

function id(){return Date.now().toString(36)+Math.random().toString(36).slice(2,8)}
function clone(o){return JSON.parse(JSON.stringify(o))}
function merge(base, saved){
  const out=clone(base);
  if(!saved)return out;
  Object.keys(out).forEach(k=>{
    if(saved[k]!==undefined && typeof out[k]==="object" && !Array.isArray(out[k]) && saved[k] && typeof saved[k]==="object") out[k]={...out[k],...saved[k]};
    else if(saved[k]!==undefined) out[k]=saved[k];
  });
  return out;
}
function load(){try{return merge(DEFAULTS,JSON.parse(localStorage.getItem(KEY)))}catch(e){return clone(DEFAULTS)}}
function save(){localStorage.setItem(KEY,JSON.stringify(state))}
function $(s){return document.querySelector(s)}
function $$(s){return [...document.querySelectorAll(s)]}
function esc(v=""){return String(v).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]))}
function toast(msg){const el=$("#toast");el.textContent=msg;el.classList.add("show");clearTimeout(toast.t);toast.t=setTimeout(()=>el.classList.remove("show"),2200)}
function localDate(d=new Date()){const y=d.getFullYear(),m=String(d.getMonth()+1).padStart(2,"0"),day=String(d.getDate()).padStart(2,"0");return `${y}-${m}-${day}`}
function parseDateTime(date,time){return new Date(`${date}T${time||"23:59"}`)}
function dayName(d=new Date()){return DAYS[d.getDay()===0?6:d.getDay()-1]}
function formatDate(date=new Date()){return date.toLocaleDateString(undefined,{weekday:"long",month:"long",day:"numeric",year:"numeric"})}
function formatTime(time){
  if(!time)return "";
  if(state.settings.timeFormat==="24")return time;
  const [h,m]=time.split(":").map(Number), suffix=h>=12?"PM":"AM", hh=h%12||12;
  return `${hh}:${String(m).padStart(2,"0")} ${suffix}`;
}
function dateLabel(date){if(!date)return "";const d=parseDateTime(date,"12:00"),now=new Date();if(localDate(d)===localDate(now))return "Today";return d.toLocaleDateString(undefined,{month:"short",day:"numeric"})}
function priorityRank(p){return {High:0,Medium:1,Low:2}[p]??3}
function taskStatus(t){return t.status==="Completed"||t.progress>=100}
function dueText(t){
  if(!t.dueDate)return "No due date";
  const due=parseDateTime(t.dueDate,t.dueTime), now=new Date();
  if(taskStatus(t))return "Completed";
  const diff=Math.ceil((new Date(t.dueDate+"T00:00:00")-new Date(localDate(now)+"T00:00:00"))/86400000);
  if(diff<0)return `${Math.abs(diff)} day${Math.abs(diff)===1?"":"s"} overdue`;
  if(diff===0)return "Due today";
  return `${diff} day${diff===1?"":"s"} left`;
}
function init(){
  applyAppearance();
  bindNav();
  bindGlobal();
  populateSettings();
  populateClassTypes();
  initTimer();
  renderAll();
  updateClock();
  setInterval(updateClock,1000);
  if(!state.profile.name || state.profile.name==="Student") maybeSetup();
}
function bindNav(){
  $$(".nav-item,[data-section]").forEach(btn=>btn.addEventListener("click",()=>{
    const sec=btn.dataset.section;if(sec)showSection(sec);
  }));
  $("#mobileMenu").onclick=()=>$("#sidebar").classList.toggle("open");
}
function showSection(sec){
  $$(".page-section").forEach(s=>s.classList.toggle("active",s.id===`section-${sec}`));
  $$(".nav-item").forEach(n=>n.classList.toggle("active",n.dataset.section===sec));
  $("#pageTitle").textContent=sec.charAt(0).toUpperCase()+sec.slice(1);
  $("#sidebar").classList.remove("open");
  window.scrollTo({top:0,behavior:state.settings.reduceMotion?"auto":"smooth"});
  if(sec==="settings")populateSettings();
}
function bindGlobal(){
  $("#themeToggle").onclick=()=>{state.settings.theme=document.body.classList.contains("dark")?"light":"dark";save();applyAppearance();populateSettings()};
  $("#globalSearch").oninput=e=>{if(e.target.value.trim())globalSearch(e.target.value.trim())};
  $("#assignmentSearch").oninput=renderAssignments;$("#assignmentFilter").onchange=renderAssignments;$("#assignmentSort").onchange=renderAssignments;
  $("#noteSearch").oninput=renderNotes;$("#showArchived").onclick=()=>{archivedVisible=!archivedVisible;$("#showArchived").textContent=archivedVisible?"Hide archived":"Show archived";renderNotes()};
  $("#fileSearch").oninput=renderFiles;$("#fileCategory").onchange=renderFiles;
  $("#saveProfile").onclick=saveProfile;$("#saveScheduleSettings").onclick=saveScheduleSettings;$("#saveTaskSettings").onclick=saveTaskSettings;$("#saveGradePrefs").onclick=saveGradePrefs;$("#saveFocusSettings").onclick=saveFocusSettings;$("#saveAppearance").onclick=saveAppearance;$("#saveWidgets").onclick=saveWidgets;
  $("#addGradeCategory").onclick=()=>{state.grades.push({id:id(),name:"Other",score:"",max:"100",weight:"0"});save();renderGrades()};
  $("#saveGradeSettings").onclick=()=>{save();toast("Grade settings saved")};
  $("#exportData").onclick=exportData;$("#importData").onclick=()=>$("#importInput").click();$("#importInput").onchange=importData;
  $("#resetData").onclick=()=>{if(confirm("Reset all dashboard data? This cannot be undone.")){localStorage.removeItem(KEY);location.reload()}};
  $("#closeModal").onclick=closeModal;$("#modalBackdrop").addEventListener("click",e=>{if(e.target.id==="modalBackdrop")closeModal()});
  document.addEventListener("keydown",e=>{if(e.key==="Escape")closeModal()});
  $$("[data-add]").forEach(btn=>btn.addEventListener("click",()=>openEditor(btn.dataset.add)));
}
function updateClock(){
  const now=new Date(), greet=now.getHours()<12?"Good morning":now.getHours()<18?"Good afternoon":"Good evening";
  $("#headerDate").textContent=formatDate(now);$("#dashboardDate").textContent=formatDate(now);$("#dashboardTime").textContent=now.toLocaleTimeString(undefined,{hour:"2-digit",minute:"2-digit"});
  $("#greetingLabel").textContent=greet;$("#welcomeTitle").textContent=`${greet}, ${state.profile.name}.`;$("#welcomeMessage").textContent=state.profile.greeting;
  renderDashboard();
}
function applyAppearance(){
  const theme=state.settings.theme==="system"?(matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light"):state.settings.theme;
  document.body.classList.toggle("dark",theme==="dark");document.body.classList.toggle("compact",state.settings.layout==="compact");
  document.body.classList.remove("radius-sharp","radius-round");if(state.settings.radius==="sharp")document.body.classList.add("radius-sharp");if(state.settings.radius==="round")document.body.classList.add("radius-round");
  $("#themeToggle").textContent=theme==="dark"?"D":"L";
}
function renderAll(){renderIdentity();renderDashboard();renderSchedule();renderAssignments();renderSubjects();renderGrades();renderFocus();renderNotes();renderFiles()}
function renderIdentity(){const p=state.profile;$("#brandName").textContent=p.school||"CollegeOS";$("#sidebarName").textContent=p.name||"Student";$("#sidebarProgram").textContent=p.program||"My Program";$("#sidebarAvatar").textContent=(p.name||"S").trim().charAt(0).toUpperCase()}
function renderDashboard(){
  const today=dayName(), classes=state.classes.filter(c=>c.day===today).sort((a,b)=>a.start.localeCompare(b.start)), tasks=state.assignments.filter(t=>t.dueDate===localDate()&&!taskStatus(t));
  $("#statClasses").textContent=classes.length;$("#statClassesMeta").textContent=classes.length?`${classes[0].start} - ${classes[classes.length-1].end}`:"No classes scheduled";
  $("#statTasks").textContent=tasks.length;$("#statTasksMeta").textContent=tasks.length?`${tasks.length} task${tasks.length>1?"s":""} need attention`:"Nothing due today";
  const done=state.assignments.filter(taskStatus).length,total=state.assignments.length,pct=total?Math.round(done/total*100):0;
  $("#statCompletion").textContent=pct+"%";$("#statFocus").textContent=state.focus.sessions||0;$("#weeklyPercent").textContent=pct+"%";$("#weeklySummary").textContent=`${done} of ${total} tasks completed`;
  $("#focusMinutes").textContent=(state.focus.minutes||0)+" min";$("#focusSessionLabel").textContent=state.focus.sessions?`${state.focus.sessions} completed focus sessions`:"No sessions yet";
  const widgetMap={nextClass:"widget-next-class",todaySchedule:"widget-today-schedule",todayTasks:"widget-today-tasks",deadlines:"widget-deadlines",weeklyProgress:"widget-weekly-progress",focusStats:"widget-focus-stats",quickActions:"widget-quick-actions"};
  Object.entries(widgetMap).forEach(([key,id])=>{const el=$("#"+id);if(el)el.style.display=state.widgets[key]?"":"none"});
  const now=new Date(), upcoming=state.classes.map(c=>({...c,when:nextOccurrence(c)})).filter(c=>c.when&&c.when>=now).sort((a,b)=>a.when-b.when)[0];
  $("#nextClass").innerHTML=upcoming?`<div class="next-class"><div><span class="badge">${esc(upcoming.type)}</span><h4>${esc(upcoming.subject)}</h4><div class="next-meta"><span class="badge">${formatTime(upcoming.start)} - ${formatTime(upcoming.end)}</span><span class="badge">${esc(upcoming.location||"No location")}</span></div></div><div class="countdown" data-countdown="${upcoming.when.toISOString()}">${countdown(upcoming.when)}</div></div>`:`<div class="empty"><strong>No upcoming classes</strong>Add a class to see your next session here.<br><button class="secondary-button" data-add="class">Add class</button></div>`;
  bindDynamicAdds();
  $("#todaySchedule").innerHTML=classes.length?classes.map(c=>scheduleItem(c)).join(""):`<div class="empty"><strong>No classes scheduled</strong>Your ${today} is currently open.</div>`;
  $("#todayTasks").innerHTML=tasks.length?tasks.slice(0,6).map(taskMini).join(""):`<div class="empty"><strong>No tasks due today</strong>You are clear for today.</div>`;
  const upcomingTasks=state.assignments.filter(t=>t.dueDate&&!taskStatus(t)).sort((a,b)=>parseDateTime(a.dueDate,a.dueTime)-parseDateTime(b.dueDate,b.dueTime)).slice(0,5);
  $("#upcomingDeadlines").innerHTML=upcomingTasks.length?upcomingTasks.map(t=>`<div class="deadline-item"><div><strong>${esc(t.title)}</strong><div class="schedule-details">${esc(t.subject||"No subject")}</div></div><span>${dateLabel(t.dueDate)}<br>${dueText(t)}</span></div>`).join(""):`<div class="empty"><strong>No upcoming deadlines</strong>Add an assignment when something is due.</div>`;
}
function countdown(date){let ms=new Date(date)-new Date();if(ms<0)return "Now";let d=Math.floor(ms/86400000);ms%=86400000;let h=Math.floor(ms/3600000);ms%=3600000;let m=Math.floor(ms/60000);if(d)return `In ${d}d ${h}h`;if(h)return `In ${h}h ${m}m`;return `In ${m}m`}
function nextOccurrence(c){
  const now=new Date(), idx=DAYS.indexOf(c.day);if(idx<0)return null;let diff=idx-(now.getDay()===0?6:now.getDay()-1);if(diff<0)diff+=7;
  let d=new Date(now);d.setDate(now.getDate()+diff);let candidate=parseDateTime(localDate(d),c.start);if(diff===0&&candidate<now)d.setDate(d.getDate()+7);return parseDateTime(localDate(d),c.start)
}
function scheduleItem(c){return `<div class="schedule-item"><div class="schedule-time">${formatTime(c.start)}<br>${formatTime(c.end)}</div><div><div class="schedule-subject">${esc(c.subject)}</div><div class="schedule-details">${esc(c.location||"No location")} · ${esc(c.type)}</div></div><span class="status-dot"></span></div>`}
function taskMini(t){return `<div class="task-row ${taskStatus(t)?"done":""}"><button class="task-check ${taskStatus(t)?"done":""}" data-task-check="${t.id}">${taskStatus(t)?"OK":""}</button><div class="task-info"><strong>${esc(t.title)}</strong><span>${esc(t.subject||"No subject")} · ${dueText(t)}</span></div></div>`}
function bindDynamicAdds(){document.querySelectorAll("[data-add]").forEach(b=>{if(!b.dataset.bound){b.dataset.bound="1";b.onclick=()=>openEditor(b.dataset.add)}});$$("[data-task-check]").forEach(b=>{if(!b.dataset.bound){b.dataset.bound="1";b.onclick=()=>toggleTask(b.dataset.taskCheck)}})}
function renderSchedule(){
  const grid=$("#scheduleGrid");grid.innerHTML=DAYS.map(day=>{const items=state.classes.filter(c=>c.day===day).sort((a,b)=>a.start.localeCompare(b.start));return `<div class="day-column"><div class="day-header"><strong>${day}</strong><span>${items.length} class${items.length===1?"":"es"}</span></div>${items.length?items.map(c=>`<div class="class-card"><h4>${esc(c.subject)}</h4><p>${formatTime(c.start)} - ${formatTime(c.end)}</p><p>${esc(c.location||"No location")} · ${esc(c.type)}</p><p>${esc(c.instructor||"No instructor")}${c.room?" · "+esc(c.room):""}</p><div class="class-actions"><button class="small-button" data-edit-class="${c.id}">Edit</button><button class="small-button" data-dup-class="${c.id}">Duplicate</button><button class="small-button" data-del-class="${c.id}">Delete</button></div></div>`).join(""):`<div class="day-empty">No classes</div>`}</div>`}).join("");
  $$("[data-edit-class]").forEach(b=>b.onclick=()=>openEditor("class",b.dataset.editClass));$$("[data-dup-class]").forEach(b=>b.onclick=()=>duplicateClass(b.dataset.dupClass));$$("[data-del-class]").forEach(b=>b.onclick=()=>deleteItem("class",b.dataset.delClass));
}
function renderAssignments(){
  const q=($("#assignmentSearch")?.value||"").toLowerCase(),filter=$("#assignmentFilter")?.value||"all",sort=$("#assignmentSort")?.value||"due";let list=state.assignments.filter(t=>(t.title+" "+t.subject+" "+t.description).toLowerCase().includes(q));
  const now=new Date(),today=localDate();
  list=list.filter(t=>filter==="all"||filter==="completed"&&taskStatus(t)||filter==="today"&&t.dueDate===today&&!taskStatus(t)||filter==="upcoming"&&t.dueDate>today&&!taskStatus(t)||filter==="overdue"&&t.dueDate<today&&!taskStatus(t));
  list.sort((a,b)=>sort==="title"?a.title.localeCompare(b.title):sort==="priority"?priorityRank(a.priority)-priorityRank(b.priority):sort==="progress"?(b.progress||0)-(a.progress||0):parseDateTime(a.dueDate||"9999-12-31",a.dueTime)-parseDateTime(b.dueDate||"9999-12-31",b.dueTime));
  $("#assignmentList").innerHTML=list.length?list.map(t=>`<div class="assignment-row"><div class="assignment-title"><strong>${esc(t.title)}</strong><span>${esc(t.subject||"No subject")} · ${esc(t.dueDate?dateLabel(t.dueDate):"No due date")}</span></div><div><div class="progress-mini"><span style="width:${Math.min(100,t.progress||0)}%"></span></div><span class="schedule-details">${t.progress||0}%</span></div><div class="priority">${esc(t.priority)}</div><div class="assignment-status status">${esc(t.status)}</div><div class="status">${esc(dueText(t))}</div><div class="row-actions"><button class="row-button" data-edit-task="${t.id}">Edit</button><button class="row-button" data-toggle-task="${t.id}">${taskStatus(t)?"Undo":"Done"}</button><button class="row-button" data-del-task="${t.id}">Delete</button></div></div>`).join(""):`<div class="empty"><strong>No assignments found</strong>Add a task or adjust your filters.</div>`;
  $$("[data-edit-task]").forEach(b=>b.onclick=()=>openEditor("assignment",b.dataset.editTask));$$("[data-toggle-task]").forEach(b=>b.onclick=()=>toggleTask(b.dataset.toggleTask));$$("[data-del-task]").forEach(b=>b.onclick=()=>deleteItem("assignment",b.dataset.delTask));
}
function toggleTask(taskId){const t=state.assignments.find(x=>x.id===taskId);if(!t)return;t.status=taskStatus(t)?"Not Started":"Completed";t.progress=taskStatus(t)?100:0;save();renderAll();toast(t.status==="Completed"?"Task completed":"Task reopened")}
function renderSubjects(){
  $("#subjectGrid").innerHTML=state.subjects.length?state.subjects.map(s=>`<article class="card subject-card"><span class="subject-code">${esc(s.code||"NO CODE")}</span><h3>${esc(s.name)}</h3><div class="subject-meta"><div><span>Instructor</span><strong>${esc(s.instructor||"Not set")}</strong></div><div><span>Room</span><strong>${esc(s.room||"Not set")}</strong></div><div><span>Priority</span><strong>${esc(s.priority||"Normal")}</strong></div></div><p class="schedule-details">${esc(s.description||s.notes||"No description.")}</p><div class="card-actions"><button class="secondary-button" data-edit-subject="${s.id}">Edit</button><button class="secondary-button" data-del-subject="${s.id}">Delete</button></div></article>`).join(""):`<div class="empty"><strong>No subjects yet</strong>Add your first subject to organize classes and grades.</div>`;
  $$("[data-edit-subject]").forEach(b=>b.onclick=()=>openEditor("subject",b.dataset.editSubject));$$("[data-del-subject]").forEach(b=>b.onclick=()=>deleteItem("subject",b.dataset.delSubject));
}
function renderGrades(){
  $("#gradeCategories").innerHTML=state.grades.map(g=>`<div class="grade-row" data-grade="${g.id}"><input class="field grade-name" value="${esc(g.name)}" placeholder="Category"><input class="field grade-score" type="number" min="0" value="${esc(g.score)}" placeholder="Score"><input class="field grade-max" type="number" min="1" value="${esc(g.max)}" placeholder="Max"><input class="field grade-weight" type="number" min="0" value="${esc(g.weight)}" placeholder="Weight"><button class="row-button grade-delete" data-id="${g.id}">Delete</button></div>`).join("");
  $$(".grade-row").forEach(row=>row.querySelectorAll("input").forEach(input=>input.oninput=()=>{const g=state.grades.find(x=>x.id===row.dataset.grade);g.name=row.querySelector(".grade-name").value;g.score=row.querySelector(".grade-score").value;g.max=row.querySelector(".grade-max").value;g.weight=row.querySelector(".grade-weight").value;renderGradeSummary()}));
  $$(".grade-delete").forEach(b=>b.onclick=()=>{state.grades=state.grades.filter(g=>g.id!==b.dataset.id);save();renderGrades()});renderGradeSummary();
}
function renderGradeSummary(){
  let weight=0,weighted=0,count=0;state.grades.forEach(g=>{const s=Number(g.score),m=Number(g.max),w=Number(g.weight);if(m>0&&!Number.isNaN(s)&&g.score!==""&&w>0){weighted+=(s/m*100)*w;weight+=w;count++}});
  const grade=weight?weighted/weight:0, p=state.settings.precision;$("#overallGrade").textContent=grade.toFixed(p)+"%";$("#passingGradeDisplay").textContent=state.settings.passing+"%";$("#targetGradeDisplay").textContent=state.settings.target+"%";$("#weightedEntries").textContent=count;$("#gradeBar").style.width=Math.min(100,grade)+"%";
  $("#gradeAdvice").textContent=!count?"Add scores and weights to calculate your current grade.":grade>=state.settings.target?"You are at or above your target grade.":grade>=state.settings.passing?"You are currently passing. Keep your remaining assessments visible.":`You are below the passing grade by ${(state.settings.passing-grade).toFixed(p)} points.`;
}
function renderFocus(){
  $("#focusTotalSessions").textContent=state.focus.sessions||0;$("#focusTotalMinutes").textContent=state.focus.minutes||0;$("#focusStreak").textContent=state.focus.history.filter(x=>x.date===localDate()).length;
  $("#focusHistory").innerHTML=state.focus.history.length?state.focus.history.slice(-8).reverse().map(x=>`<div class="history-row"><span>${esc(x.date)} · ${esc(x.mode)}</span><strong>${x.minutes} min</strong></div>`).join(""):`<div class="empty"><strong>No focus sessions yet</strong>Start a session to build your history.</div>`;
  $("#timerMode").textContent=timer.mode==="focus"?"Focus":timer.mode==="short"?"Short break":timer.mode==="long"?"Long break":"Custom";updateTimerDisplay();
}
function initTimer(){setTimerMode("focus");$("#timerStart").onclick=startTimer;$("#timerPause").onclick=pauseTimer;$("#timerReset").onclick=resetTimer;$("#timerSkip").onclick=skipTimer;$$(".mode-button").forEach(b=>b.onclick=()=>setTimerMode(b.dataset.mode))}
function setTimerMode(mode){
  timer.mode=mode;timer.running=false;clearInterval(timer.interval);let mins=mode==="focus"?state.settings.focus:mode==="short"?state.settings.short:mode==="long"?state.settings.long:state.settings.focus;timer.total=mins*60;timer.remaining=timer.total;$$(".mode-button").forEach(b=>b.classList.toggle("active",b.dataset.mode===mode));updateTimerDisplay();
}
function startTimer(){if(timer.running)return;timer.running=true;timer.interval=setInterval(()=>{timer.remaining--;updateTimerDisplay();if(timer.remaining<=0)finishTimer()},1000)}
function pauseTimer(){timer.running=false;clearInterval(timer.interval);updateTimerDisplay()}
function resetTimer(){pauseTimer();setTimerMode(timer.mode)}
function skipTimer(){pauseTimer();const next=timer.mode==="focus"?"short":"focus";setTimerMode(next)}
function finishTimer(){pauseTimer();if(timer.mode==="focus"){state.focus.sessions++;state.focus.minutes+=Math.round(timer.total/60);state.focus.history.push({date:localDate(),mode:"Focus",minutes:Math.round(timer.total/60)});save();toast("Focus session completed")}setTimerMode(timer.mode==="focus"&&state.focus.sessions%state.settings.sessionsLong===0?"long":timer.mode==="focus"?"short":"focus");renderFocus();renderDashboard()}
function updateTimerDisplay(){const m=Math.floor(timer.remaining/60),s=timer.remaining%60;$("#timerDisplay").textContent=`${String(m).padStart(2,"0")}:${String(s).padStart(2,"0")}`;$("#timerProgress").style.width=(timer.total?Math.max(0,Math.min(100,(1-timer.remaining/timer.total)*100)):0)+"%";$("#timerStart").textContent=timer.running?"Running":"Start"}
function renderNotes(){
  const q=($("#noteSearch")?.value||"").toLowerCase();let list=state.notes.filter(n=>archivedVisible?n.archived:(n.archived!==true)).filter(n=>(n.title+" "+n.content+" "+n.subject).toLowerCase().includes(q)).sort((a,b)=>Number(b.pinned)-Number(a.pinned)||new Date(b.updated)-new Date(a.updated));
  $("#noteGrid").innerHTML=list.length?list.map(n=>`<article class="card note-card ${n.pinned?"pinned":""}"><span class="eyebrow">${n.pinned?"Pinned":"Note"}${n.subject?" · "+esc(n.subject):""}</span><h3>${esc(n.title)}</h3><div class="note-content">${esc(n.content)}</div><div class="note-footer"><span>Updated ${esc(dateLabel(n.updated.slice(0,10)))}</span><div><button class="row-button" data-pin-note="${n.id}">${n.pinned?"Unpin":"Pin"}</button><button class="row-button" data-archive-note="${n.id}">${n.archived?"Restore":"Archive"}</button><button class="row-button" data-edit-note="${n.id}">Edit</button><button class="row-button" data-del-note="${n.id}">Delete</button></div></div></article>`).join(""):`<div class="empty"><strong>${archivedVisible?"No archived notes":"No notes yet"}</strong>Create a note to keep important information in one place.</div>`;
  $$("[data-pin-note]").forEach(b=>b.onclick=()=>noteAction(b.dataset.pinNote,"pin"));$$("[data-archive-note]").forEach(b=>b.onclick=()=>noteAction(b.dataset.archiveNote,"archive"));$$("[data-edit-note]").forEach(b=>b.onclick=()=>openEditor("note",b.dataset.editNote));$$("[data-del-note]").forEach(b=>b.onclick=()=>deleteItem("note",b.dataset.delNote));
}
function noteAction(noteId,action){const n=state.notes.find(x=>x.id===noteId);if(!n)return;if(action==="pin")n.pinned=!n.pinned;else n.archived=!n.archived;n.updated=new Date().toISOString();save();renderNotes()}
function renderFiles(){
  const q=($("#fileSearch")?.value||"").toLowerCase(),cat=$("#fileCategory")?.value||"all";const list=state.files.filter(f=>(cat==="all"||f.category===cat)&&(f.name+" "+f.description+" "+f.subject).toLowerCase().includes(q));
  $("#fileGrid").innerHTML=list.length?list.map(f=>`<article class="card resource-card"><span class="eyebrow">${esc(f.category||"Other")}</span><h3>${esc(f.name)}</h3><p class="resource-description">${esc(f.description||"No description.")}</p><div class="resource-url"><a href="${safeUrl(f.url)}" target="_blank" rel="noopener noreferrer">${esc(f.url)}</a></div><div class="resource-meta">${f.subject?`<span class="badge">${esc(f.subject)}</span>`:""}</div><div class="card-actions"><button class="secondary-button" data-edit-file="${f.id}">Edit</button><button class="secondary-button" data-del-file="${f.id}">Delete</button></div></article>`).join(""):`<div class="empty"><strong>No saved files</strong>Add a URL or school resource to build your library.</div>`;
  $$("[data-edit-file]").forEach(b=>b.onclick=()=>openEditor("file",b.dataset.editFile));$$("[data-del-file]").forEach(b=>b.onclick=()=>deleteItem("file",b.dataset.delFile));
}
function safeUrl(url){try{const u=new URL(url);return ["http:","https:"].includes(u.protocol)?u.href:"#"}catch(e){return "#"}}
function openEditor(type,editId=null){
  const item=editId?({class:state.classes,assignment:state.assignments,subject:state.subjects,note:state.notes,file:state.files}[type]||[]).find(x=>x.id===editId):null;
  const form=$("#modalForm");$("#modalTitle").textContent=(item?"Edit ":"Add ")+({class:"class",assignment:"assignment",subject:"subject",note:"note",file:"resource"}[type]);$("#modalEyebrow").textContent="Editor";
  let body="";
  if(type==="class")body=`<div class="modal-form-grid">
    <label>Subject<select class="field" name="subject"><option value="">Choose subject</option>${state.subjects.map(s=>`<option ${item?.subject===s.name?"selected":""}>${esc(s.name)}</option>`).join("")}</select></label>
    <label>Day<select class="field" name="day">${DAYS.map(d=>`<option ${item?.day===d?"selected":""}>${d}</option>`).join("")}</select></label>
    <label>Start time<input class="field" name="start" type="time" value="${item?.start||"08:00"}"></label>
    <label>End time<input class="field" name="end" type="time" value="${item?.end||"09:00"}"></label>
    <label>Location<input class="field" name="location" value="${esc(item?.location||"")}"></label>
    <label>Class type<select class="field" name="type">${state.classTypes.map(x=>`<option ${item?.type===x?"selected":""}>${esc(x)}</option>`).join("")}</select></label>
    <label>Instructor<input class="field" name="instructor" value="${esc(item?.instructor||"")}"></label><label>Room<input class="field" name="room" value="${esc(item?.room||"")}"></label>
    <label class="full">Notes<textarea class="field" name="notes">${esc(item?.notes||"")}</textarea></label></div>`;
  if(type==="assignment")body=`<div class="modal-form-grid">
    <label class="full">Title<input class="field" name="title" required value="${esc(item?.title||"")}"></label>
    <label>Subject<select class="field" name="subject"><option value="">No subject</option>${state.subjects.map(s=>`<option ${item?.subject===s.name?"selected":""}>${esc(s.name)}</option>`).join("")}</select></label>
    <label>Priority<select class="field" name="priority">${["Low","Medium","High"].map(x=>`<option ${item?.priority===x||(!item&&state.settings.defaultPriority===x)?"selected":""}>${x}</option>`).join("")}</select></label>
    <label>Due date<input class="field" name="dueDate" type="date" value="${item?.dueDate||""}"></label><label>Due time<input class="field" name="dueTime" type="time" value="${item?.dueTime||"23:59"}"></label>
    <label>Status<select class="field" name="status">${["Not Started","In Progress","Completed"].map(x=>`<option ${item?.status===x||(!item&&state.settings.defaultTaskStatus===x)?"selected":""}>${x}</option>`).join("")}</select></label>
    <label>Progress<input class="field" name="progress" type="number" min="0" max="100" value="${item?.progress??0}"></label>
    <label class="full">Description<textarea class="field" name="description">${esc(item?.description||"")}</textarea></label>
    <label class="full">Notes<textarea class="field" name="notes">${esc(item?.notes||"")}</textarea></label></div>`;
  if(type==="subject")body=`<div class="modal-form-grid"><label>Name<input class="field" name="name" required value="${esc(item?.name||"")}"></label><label>Subject code<input class="field" name="code" value="${esc(item?.code||"")}"></label><label>Instructor<input class="field" name="instructor" value="${esc(item?.instructor||"")}"></label><label>Room<input class="field" name="room" value="${esc(item?.room||"")}"></label><label>Priority<select class="field" name="priority">${["Low","Normal","High"].map(x=>`<option ${item?.priority===x?"selected":""}>${x}</option>`).join("")}</select></label><label class="full">Description<textarea class="field" name="description">${esc(item?.description||"")}</textarea></label><label class="full">Notes<textarea class="field" name="notes">${esc(item?.notes||"")}</textarea></label></div>`;
  if(type==="note")body=`<div class="modal-form-grid"><label class="full">Title<input class="field" name="title" required value="${esc(item?.title||"")}"></label><label>Subject<select class="field" name="subject"><option value="">No subject</option>${state.subjects.map(s=>`<option ${item?.subject===s.name?"selected":""}>${esc(s.name)}</option>`).join("")}</select></label><label class="check-label"><input type="checkbox" name="pinned" ${item?.pinned?"checked":""}> Pin note</label><label class="full">Content<textarea class="field" name="content">${esc(item?.content||"")}</textarea></label></div>`;
  if(type==="file")body=`<div class="modal-form-grid"><label class="full">File or resource name<input class="field" name="name" required value="${esc(item?.name||"")}"></label><label class="full">File URL<input class="field" name="url" type="url" required placeholder="https://example.com" value="${esc(item?.url||"")}"></label><label>Category<select class="field" name="category">${["Modules","Assignments","References","School Links","Other"].map(x=>`<option ${item?.category===x?"selected":""}>${x}</option>`).join("")}</select></label><label>Subject<input class="field" name="subject" value="${esc(item?.subject||"")}"></label><label class="full">Description<textarea class="field" name="description">${esc(item?.description||"")}</textarea></label></div>`;
  form.innerHTML=body+`<div class="modal-actions"><button type="button" class="secondary-button" id="cancelModal">Cancel</button><button class="primary-button">Save</button></div>`;
  $("#cancelModal").onclick=closeModal;form.onsubmit=e=>{e.preventDefault();saveEditor(type,editId,new FormData(form));};
  $("#modalBackdrop").hidden=false;setTimeout(()=>form.querySelector("input,select,textarea")?.focus(),20);
}
function saveEditor(type,editId,fd){
  const target={class:state.classes,assignment:state.assignments,subject:state.subjects,note:state.notes,file:state.files}[type];let obj=editId?target.find(x=>x.id===editId):{id:id()};
  if(type==="class")Object.assign(obj,{subject:fd.get("subject")||"Untitled class",day:fd.get("day"),start:fd.get("start"),end:fd.get("end"),location:fd.get("location"),type:fd.get("type"),instructor:fd.get("instructor"),room:fd.get("room"),notes:fd.get("notes")});
  if(type==="assignment")Object.assign(obj,{title:fd.get("title"),subject:fd.get("subject"),priority:fd.get("priority"),dueDate:fd.get("dueDate"),dueTime:fd.get("dueTime"),status:fd.get("status"),progress:Math.max(0,Math.min(100,Number(fd.get("progress"))||0)),description:fd.get("description"),notes:fd.get("notes")});
  if(type==="subject")Object.assign(obj,{name:fd.get("name"),code:fd.get("code"),instructor:fd.get("instructor"),room:fd.get("room"),priority:fd.get("priority"),description:fd.get("description"),notes:fd.get("notes")});
  if(type==="note")Object.assign(obj,{title:fd.get("title"),subject:fd.get("subject"),content:fd.get("content"),pinned:fd.get("pinned")==="on",archived:obj.archived||false,created:obj.created||new Date().toISOString(),updated:new Date().toISOString()});
  if(type==="file")Object.assign(obj,{name:fd.get("name"),url:fd.get("url"),category:fd.get("category"),subject:fd.get("subject"),description:fd.get("description")});
  if(!editId)target.push(obj);save();closeModal();renderAll();toast("Saved successfully");
}
function closeModal(){$("#modalBackdrop").hidden=true;$("#modalForm").innerHTML=""}
function duplicateClass(cid){const c=state.classes.find(x=>x.id===cid);if(!c)return;const copy={...c,id:id()};state.classes.push(copy);save();renderSchedule();renderDashboard();toast("Class duplicated")}
function deleteItem(type,itemId){if(!confirm("Delete this item?"))return;const arr={class:state.classes,assignment:state.assignments,subject:state.subjects,note:state.notes,file:state.files}[type];const i=arr.findIndex(x=>x.id===itemId);if(i>=0){arr.splice(i,1);save();renderAll();toast("Deleted")}}
function globalSearch(q){
  const hits=[...state.subjects.map(x=>["Subject",x.name,"subjects"]),...state.classes.map(x=>["Class",x.subject,"schedule"]),...state.assignments.map(x=>["Assignment",x.title,"assignments"]),...state.notes.map(x=>["Note",x.title,"notes"]),...state.files.map(x=>["Resource",x.name,"files"])].filter(x=>x[1].toLowerCase().includes(q.toLowerCase()));
  if(hits.length){showSection(hits[0][2]);toast(`${hits.length} result${hits.length>1?"s":""} found in ${hits[0][0]}s`)}else toast("No matches found");
}
function populateClassTypes(){const options=state.classTypes.map(x=>`<option>${esc(x)}</option>`).join("");$("#setClassType").innerHTML=options}
function populateSettings(){
  const p=state.profile,s=state.settings;const map={setName:p.name,setStudentId:p.studentId,setProgram:p.program,setYear:p.year,setSection:p.section,setSchool:p.school,setEmail:p.email,setGreeting:p.greeting,setWeekStart:s.weekStart,setTimeFormat:s.timeFormat,setClassDuration:s.classDuration,setClassType:s.defaultClassType,setPriority:s.defaultPriority,setTaskStatus:s.defaultTaskStatus,setSortOrder:s.sortOrder,setPassing:s.passing,setTarget:s.target,setPrecision:s.precision,setGradingSystem:s.gradingSystem,setFocus:s.focus,setShort:s.short,setLong:s.long,setSessionsLong:s.sessionsLong,setTheme:s.theme,setLayout:s.layout,setRadius:s.radius};
  Object.entries(map).forEach(([k,v])=>{const el=$("#"+k);if(el)el.value=v});$("#setReduceMotion").checked=s.reduceMotion;
  const labels={nextClass:"Next Class",todaySchedule:"Today's Schedule",todayTasks:"Today's Tasks",deadlines:"Upcoming Deadlines",weeklyProgress:"Weekly Progress",focusStats:"Focus Statistics",quickActions:"Quick Actions"};
  $("#widgetChecks").innerHTML=Object.entries(labels).map(([k,v])=>`<label class="widget-check"><input type="checkbox" data-widget="${k}" ${state.widgets[k]?"checked":""}>${v}</label>`).join("");
}
function saveProfile(){const p=state.profile;p.name=$("#setName").value.trim()||"Student";p.studentId=$("#setStudentId").value;p.program=$("#setProgram").value||"My Program";p.year=$("#setYear").value;p.section=$("#setSection").value;p.school=$("#setSchool").value||"My College";p.email=$("#setEmail").value;p.greeting=$("#setGreeting").value||DEFAULTS.profile.greeting;save();renderIdentity();renderDashboard();toast("Profile saved")}
function saveScheduleSettings(){const s=state.settings;s.weekStart=$("#setWeekStart").value;s.timeFormat=$("#setTimeFormat").value;s.classDuration=Number($("#setClassDuration").value)||60;s.defaultClassType=$("#setClassType").value;save();applyAppearance();renderAll();toast("Schedule settings saved")}
function saveTaskSettings(){const s=state.settings;s.defaultPriority=$("#setPriority").value;s.defaultTaskStatus=$("#setTaskStatus").value;s.sortOrder=$("#setSortOrder").value;save();toast("Task settings saved")}
function saveGradePrefs(){const s=state.settings;s.passing=Number($("#setPassing").value)||60;s.target=Number($("#setTarget").value)||90;s.precision=Number($("#setPrecision").value);s.gradingSystem=$("#setGradingSystem").value||"Weighted percentage";save();renderGrades();toast("Grade settings saved")}
function saveFocusSettings(){const s=state.settings;s.focus=Math.max(1,Number($("#setFocus").value)||25);s.short=Math.max(1,Number($("#setShort").value)||5);s.long=Math.max(1,Number($("#setLong").value)||15);s.sessionsLong=Math.max(1,Number($("#setSessionsLong").value)||4);save();setTimerMode(timer.mode);renderFocus();toast("Focus settings saved")}
function saveAppearance(){const s=state.settings;s.theme=$("#setTheme").value;s.layout=$("#setLayout").value;s.radius=$("#setRadius").value;s.reduceMotion=$("#setReduceMotion").checked;save();applyAppearance();toast("Appearance updated")}
function saveWidgets(){$$("[data-widget]").forEach(c=>state.widgets[c.dataset.widget]=c.checked);save();renderDashboard();toast("Dashboard layout saved")}
function exportData(){const blob=new Blob([JSON.stringify(state,null,2)],{type:"application/json"}),url=URL.createObjectURL(blob),a=document.createElement("a");a.href=url;a.download=`college-dashboard-backup-${localDate()}.json`;a.click();URL.revokeObjectURL(url);toast("Data exported")}
function importData(e){const file=e.target.files[0];if(!file)return;const r=new FileReader();r.onload=()=>{try{const imported=JSON.parse(r.result);state=merge(DEFAULTS,imported);save();location.reload()}catch(err){toast("Invalid backup file")}};r.readAsText(file)}
function maybeSetup(){
  if(sessionStorage.getItem("setupShown"))return;
  sessionStorage.setItem("setupShown","1");
  $("#modalTitle").textContent="Welcome";$("#modalEyebrow").textContent="First-time setup";
  $("#modalForm").innerHTML=`<p style="font-size:12px;color:var(--muted);margin-top:0">Set up the basics now. You can change everything later in Settings.</p><div class="modal-form-grid"><label>Name<input class="field" name="name" value="${esc(state.profile.name==="Student"?"":state.profile.name)}"></label><label>School<input class="field" name="school" value="${esc(state.profile.school==="My College"?"":state.profile.school)}"></label><label>Program<input class="field" name="program" value="${esc(state.profile.program==="My Program"?"":state.profile.program)}"></label><label>Year level<input class="field" name="year"></label></div><div class="modal-actions"><button type="button" class="secondary-button" id="skipSetup">Skip setup</button><button class="primary-button">Continue</button></div>`;
  $("#skipSetup").onclick=closeModal;$("#modalForm").onsubmit=e=>{e.preventDefault();const fd=new FormData(e.target);state.profile.name=fd.get("name")||"Student";state.profile.school=fd.get("school")||"My College";state.profile.program=fd.get("program")||"My Program";state.profile.year=fd.get("year")||"";save();closeModal();renderAll();toast("Welcome to your dashboard")};$("#modalBackdrop").hidden=false;
}
document.addEventListener("DOMContentLoaded",init);
